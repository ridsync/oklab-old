package com.essence.chart_sdk;

import android.widget.CompoundButton;


public interface ChartCheckBoxListenerCallback {
	public void onCheckedChanged(CompoundButton buttonView, boolean isChecked);
}
